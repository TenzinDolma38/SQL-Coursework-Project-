﻿use librarysystem

--	1.List the title of the book that is the most popular book to be borrowed. 
--(Namely, it has been borrowed most often number of times )

select B1.ISBN, title, count(bl1.copyid) as copycount
from book b1
inner join BookCopies  bc1
on bc1.isbn=b1.ISBN
inner join BorrowedLog bl1
on bl1.CopyId=bc1.CopyID
group by B1.ISBN,B1.Title
having count(bl1.copyid)=
	(select max(BorrowedCopies) as mostBorrowed
	from 
		(select bc.CopyID, count(bl.CopyId) as BorrowedCopies
		from book b
		inner join BookCopies  bc
		on bc.isbn=b.ISBN
		inner join BorrowedLog bl
		on bl.CopyId=bc.CopyID
		group by bc.CopyID) MostBorrowedBook)





--		Which librarian has the third highest salary at the current time?

with cte_salary as

(select librarianid,dense_rank() over(order by salary desc) as ranks
from librarian )

select * from cte_salary
where ranks=3

--		For each employee, list his/her name and the name of the branch for 
--which he/she is currently working and how many employees are working for that branch. 


SELECT e.FName,e.Lname, b.BranchName, count(e.employeeid) over(partition by b.branchname) as BranchEmployeeCount
from Employees e
inner join Branches b
on b.BranchID= e.branchid


--	 For each book, list the title and publisher of the book and
--the number of copies currently stocked for this title in each branch,
--regardless of whether it is currently on loan.

select distinct b.title, p.Name,bc.BranchID, count(bc.copyid) as NumOfCopies
from Publisher p
inner join book b  
on p.PublisherID=b.PublisherID
inner join BookCopies bc
on bc.isbn=b.ISBN
inner join branches br
on br.branchID=bc.BranchID
group by b.Title,p.Name, bc.BranchID

select* from BookCopies



--		For each quarter of the current year, for each branch list the total amount of books that
--have been borrowed in that quarter. The first quarter is months Jan, Feb, Mar. 
--The second quarter is months Apr , May , June etc.  List the amounts for each of these quarters, on the same row.
SELECT  B.[BranchName]
        ,(
            SELECT COUNT(BB.Copyid) AS [Total]
            FROM BookCopies BC 
            INNER JOIN BorrowedLog BB 
			ON BB.Copyid = BC.Copyid
            WHERE MONTH(BB.BorrowedDate) IN (1,2,3) 
        ) AS Firstquartercount
        ,(
            SELECT COUNT(BB.Copyid) AS [Total]
            FROM BookCopies BC
            INNER JOIN BorrowedLog BB
			ON BB.Copyid = BC.Copyid
            WHERE MONTH(BB.borrowedDate) IN (4,5,6) 
        ) AS Secondquartercount
        ,(
            SELECT COUNT(BB.Copyid) AS [Total]
            FROM BookCopies BC
            INNER JOIN BorrowedLog BB 
			ON BB.Copyid = BC.Copyid
            WHERE MONTH(BB.borrowedDate) IN (7,8,9) 
        ) AS thirdquartercount
        ,(
            SELECT COUNT(BB.Copyid) AS [Total]
            FROM BookCopies BC 
            INNER JOIN BorrowedLog BB 
			ON BB.Copyid = BC.Copyid
            WHERE MONTH(BB.borrowedDate) IN (10,11,12) 
        ) AS fourthQuarterCount
FROM Branches B








--		For each card, list the name of the borrower and the name of the books he currently
--has borrowed on the card, that have not yet been returned
SELECT L.CardID, M.FName, M.LName, B.Title
FROM Members M
INNER JOIN Librarycard L
ON L.memberid=M.MemberID
INNER JOIN BorrowedLog BL
ON BL.CardId=L.CardID
INNER JOIN BookCopies BC
ON BC.CopyID=BL.CopyId
INNER JOIN Book B
ON B.ISBN=BC.isbn
WHERE BL.ReturnedDate IS NULL
ORDER BY L.CardID



--		For each card, list the name of the borrower and on the same 
--row the quantity of books that have been borrowed in 2020 and the quantity of books
--that have been borrowed in 2021 with that card. 

select *
from 

(SELECT L.cardid, m.FName,m.LName, CopyId, year(bl.borrowedDate) as BorrowedYear
from Members M
INNER JOIN Librarycard L
ON L.memberid=M.MemberID
INNER JOIN BorrowedLog bl
on BL.CardId=L.cardid) tt

pivot

(count(CopyId) 
for BorrowedYear in ([2020],
					 [2021]))as newtable




--		For a specific card, list which other cards borrowed 
--ALL the same books as was borrowed using this card.  (divide query). 
--You choose the card you will be matching. 

 SELECT AllBooks.CardId
FROM 
(
    SELECT DISTINCT BL.cardid,B.Title
    FROM BorrowedLog BL
    INNER JOIN bookcopies bc
	ON bc.copyid = BL.copyid
    INNER JOIN Book B 
	ON b.ISBN = BC.isbn
) AS AllBooks
JOIN 
(SELECT DISTINCT BL.cardid,B.Title
    FROM BorrowedLog BL
    INNER JOIN bookcopies bc
	ON bc.copyid = BL.copyid
    INNER JOIN Book B 
	ON b.ISBN = BC.isbn
   WHERE BL.cardid = 2
) AS BooksbyCard2

ON BooksbyCard2.Title = AllBooks.title
GROUP BY AllBooks.cardid
HAVING COUNT(AllBooks.title) =  (
                                    SELECT COUNT(B.Title)
                                    FROM BorrowedLog bl
                                    JOIN bookcopies bc 
									ON bc.copyid = bl.copyid
                                    JOIN Book B 
									ON B.ISBN = BC.isbn
                                    WHERE bl.cardid = 2
                                )


   SELECT DISTINCT BL.cardid
   FROM BorrowedLog BL
    INNER JOIN bookcopies bc
	ON bc.copyid = BL.copyid
    INNER JOIN Book B 
	ON b.ISBN = BC.isbn
 where not exists 

(SELECT DISTINCT bl.CardId
    FROM BorrowedLog BL1
    INNER JOIN bookcopies bc1
	ON bc1.copyid = BL1.copyid
    INNER JOIN Book B1
	ON b1.ISBN = BC1.isbn
   WHERE BL1.cardid = 2 and not exists 
   ( select CardId
   from BorrowedLog bl2
   where bl2.CardId=bl1.CardId
   and bl2.CardId=bl.CardId))









--		List the name of the employee that has been working for the library the longest amount of time

SELECT FNAME,LNAME
FROM Employees
WHERE DATEDIFF(YEAR,HIREDATE,GETDATE())=

(SELECT MAX(YEARSSERVED) AS MAXYEARS
FROM
(SELECT DATEDIFF(YEAR, HireDate,GETDATE()) AS YEARSSERVED
FROM Employees )MY)

--		For each book , list the title and branch that it is in, if it isnt currently on loan

SELECT b.ISBN, B.Title, bc.BranchID
FROM Book B
INNER JOIN BookCopies BC 
ON B.ISBN = BC.isbn
inner join Status s
on s.StatusID=bc.BookStatusID
where s.Description='Available'





--		List the names of borrowers and the card id that they have if it hasnt expired.


SELECT m.FName,m.LNAME,lc.CardID
FROM Librarycard lc
inner join Members m
on m.MemberID=lc.memberid

WHERE lc.expireddate>GETDATE()


--		For each author, list his name and the titles of the books he has written

SELECT AUTHOR.AuthorID,AuthorFname,AuthorLname, BOOK.Title
FROM Author
INNER JOIN AuthorBooks 
ON AuthorBooks.AuthorID =Author.AuthorID
INNER JOIN BOOK
ON BOOK.ISBN=AuthorBooks.ISBN
--		For each author, list his name and the name of categories of books he has written
SELECT AUTHOR.AuthorID,AuthorFname,AuthorLname,C.CategoryName
FROM Author
INNER JOIN AuthorBooks 
ON AuthorBooks.AuthorID =Author.AuthorID
INNER JOIN BOOK
ON BOOK.ISBN=AuthorBooks.ISBN
INNER JOIN BookCategories BC
ON BC.ISBN=BOOK.ISBN
INNER JOIN Categories C
ON C.CategoryID=BC.CategoryID

--		For each employee, calculate the amount of money he should have earned this year based on his
--logged hours.

SELECT EMPLOYEEID, SUM(PAYRATE*HoursWorked) AS TOTALMONEY
FROM Payrolls_Hourly
GROUP BY EmployeeID
--		List the title of books that have never been borrowed.



SELECT B.Title
FROM Book B
WHERE B.ISBN not IN 

	(SELECT b.ISBN
	FROM BorrowedLog  BL
	inner join BookCopies bc
	on bc.CopyID=bl.CopyId
	inner join Book b
	on b.ISBN=bc.isbn)

	

--		For each branch, list the total quantity of books, total quantity by category, total quantity by author


SELECT 
coalesce( cast( cp.branchid as varchar(15)),'Allbranch') as Branches,
coalesce (c.categoryname,'AllCategory') as categories,
coalesce (A.AUTHORLNAME+' '+a.authorlname, 'AllAuthors') AS authors,
count(cp.copyid) as totalcopies
FROM BookCopies CP
INNER JOIN Book B
ON B.ISBN=CP.isbn
INNER JOIN BookCategories BC
ON BC.ISBN=B.ISBN
INNER JOIN Categories C
ON C.CategoryID=BC.CategoryID
INNER JOIN AuthorBooks AB
ON AB.ISBN=B.ISBN
INNER JOIN Author A
ON A.AuthorID=AB.AuthorID
group by rollup(cp.BranchID,c.CategoryName,A.AUTHORLNAME+' '+a.authorlname)





--		For each card, list the name of the cardholder, list the category of books and
--each book that was borrowed on this card. In the same query list 
--to the how many books have been borrowed for each category, and how many
--books have been borrowed in total with this card.


select * from Members
SELECT 
COALESCE(CAST(m.fname + ' ' + m.lname AS VARCHAR(40)), 'ALL CARDHOLDERS') AS FullName,
COALESCE(CAST(Bl.Cardid AS VARCHAR(15)), 'ALLCARDS') AS MemberCards,
COALESCE(CAST(C.categoryname AS VARCHAR(15)), 'ALLCATEGORIES') AS Catgories,
COUNT(Bl.CopyId) AS Count_of_Books
FROM Members M

inner join Librarycard lc
on m.memberid=lc.memberid
inner join BorrowedLog BL
ON BL.CardId=lc.CardID
inner join BookCopies bc
on bc.CopyID=bl.CopyId
inner join Book b
on b.ISBN=bc.isbn
inner join BookCategories bk
on bk.ISBN=b.ISBN
inner join Categories c
on c.CategoryID=bk.CategoryID
group by cube (m.FName+ ' '+ m.LName, bl.CardId,c.CategoryName)



--		On one row, list the how many employees are currently employed for each type of employee. 
--Sample types are: Librarian, Network Administrator, Computer Programmer, IT Manager etc

select et.TypeID,et.Description,count(e.employeeid) as EmployeeCount
from Employees e
inner join EmployeeType et
on et.TypeID=e.EmployeeTypeID
group by et.TypeID,et.Description

--		What is the name of the borrower, who has currently borrowed the most books.

select lc.cardid,m.FName,m.LName,count(bl.copyid) as Book_Borr_Count
from Members m
inner join Librarycard lc
on lc.memberid=m.MemberID
inner join 
BorrowedLog bl
on bl.CardId=lc.cardid
group by lc.cardid, m.FName,m.LName
having count(bl.copyid)=

(select max(Bookcount) as MaxBookcount
from 

(select lc.CardID, count(bl.copyid) as Bookcount
from Members m
inner join Librarycard lc
on lc.memberid=m.MemberID
inner join BorrowedLog bl
on bl.CardId=lc.cardid
group by lc.CardID)mbc)

--		List the names of borrowers who have borrowed both book A and book B (you can choose the specific book titles).
select * from BorrowedLog
select * from BookCopies

select* from book

--Mature (16+) Animal Stories
--All My Friends
---109415   -155588




select distinct * 
from 

(select lc.cardid, m.FName+' '+ m.LName  as FullName
from Members m
inner join Librarycard lc
on lc.memberid=m.MemberID
inner join BorrowedLog bl
on lc.cardid=bl.CardId
inner join BookCopies bc
on bc.CopyID =bl.CopyId
inner join Book b
on b.ISBN=bc.isbn
where b.Title='Mature (16+) Animal Stories' )bookA


inner join 

(select lc.cardid, m.FName+' '+ m.LName  as FullName

from Members m
inner join Librarycard lc
on lc.memberid=m.MemberID
inner join BorrowedLog bl
on lc.cardid=bl.CardId
inner join BookCopies bc
on bc.CopyID =bl.CopyId
inner join Book b
on b.ISBN=bc.isbn
where   b.Title='All My Friends')bookb

on bookb.cardid=bookA.cardid

